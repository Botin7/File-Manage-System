# Image Upload PHP and MYSQL

Just a simple Image Upload PHP and MYSQL
version: 1.0.0

## Full Tutorial

[On YouTube](https://youtu.be/onu3w8kqASU)

## Authors

[Elias Abdurrahman](https://github.com/codingWithElias)
